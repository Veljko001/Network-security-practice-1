import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class Client {

    public Client() throws Exception{

        Socket s = new Socket("localhost", 5000);

        BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
        BufferedReader uin = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(s.getOutputStream()), true);

        while (true){
            String sodgovor = in.readLine();
            System.out.println(sodgovor);

            if (sodgovor.equals("Successful login!")) {
               break;
            }

            String sifra = uin.readLine();
            out.println(sifra);
        }


    }

    public static void main(String[] args) throws Exception{
        new Client();
    }
}
