import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class ServerThread implements Runnable{

    Socket s;

    public ServerThread(Socket s){
        this.s = s;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream())); // primanje poruke
            PrintWriter out = new PrintWriter(new OutputStreamWriter(s.getOutputStream()), true);

            out.println("Welcome, insert your username: ");
            String username = in.readLine();

            out.println(username + " insert your password: ");
            while (true) {
                String sifra = in.readLine();
                if (sifra.equals("RAFsec")) {
                    System.out.println("Username: " + username + " Password: " + sifra + " logged in!");
                    out.println("Succesful login!");
                    break;
                } else {
                    out.println("Wrong password! Try again: ");
                }
            }
            s.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
