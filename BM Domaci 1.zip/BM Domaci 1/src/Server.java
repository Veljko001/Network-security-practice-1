import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public Server() throws Exception{

        ServerSocket ss = new ServerSocket(5000);

        while (true) {
            Socket s = ss.accept();
            ServerThread st = new ServerThread(s);

            Thread thread = new Thread(st);
            thread.start();
        }

    }

    public static void main(String[] args) throws Exception{
        new Server();
    }
}
